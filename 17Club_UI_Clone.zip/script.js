
const loginBtn = document.getElementById('loginBtn');
const loginModal = document.getElementById('loginModal');
const closeModal = document.getElementById('closeModal');
const loginForm = document.getElementById('loginForm');

loginBtn.addEventListener('click', () => {
  loginModal.style.display = 'flex';
});
closeModal.addEventListener('click', () => {
  loginModal.style.display = 'none';
});
window.addEventListener('click', (e) => {
  if (e.target === loginModal) {
    loginModal.style.display = 'none';
  }
});
loginForm.addEventListener('submit', (e) => {
  e.preventDefault();
  alert('Login not implemented. This is a UI demo.');
  loginModal.style.display = 'none';
});
